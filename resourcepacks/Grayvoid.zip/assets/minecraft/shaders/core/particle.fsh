#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec2 texCoord0;
in vec4 vertexColor;

out vec4 fragColor;

// Grayvoid: totem glitter sprites are painted with this exact RGBA signature.
const vec4 GRAYVOID_TOTEM_MARK = vec4(250.0, 251.0, 252.0, 253.0) / 255.0;

void main() {
    vec4 tex = texture(Sampler0, texCoord0);
    vec4 color;
    if (all(lessThan(abs(tex - GRAYVOID_TOTEM_MARK), vec4(0.6 / 255.0)))) {
        // Totem pop: drop the hard-coded green/yellow tint, keep the fade-out alpha.
        color = vec4(1.0, 1.0, 1.0, vertexColor.a) * ColorModulator;
    } else {
        color = tex * vertexColor * ColorModulator;
    }
    if (color.a < 0.1) {
        discard;
    }
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
